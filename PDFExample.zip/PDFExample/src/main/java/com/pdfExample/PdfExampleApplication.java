package com.pdfExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PdfExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(PdfExampleApplication.class, args);
	}

}

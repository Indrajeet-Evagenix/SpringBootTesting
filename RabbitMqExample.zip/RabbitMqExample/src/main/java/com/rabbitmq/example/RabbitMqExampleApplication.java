package com.rabbitmq.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RabbitMqExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(RabbitMqExampleApplication.class, args);
	}

}
